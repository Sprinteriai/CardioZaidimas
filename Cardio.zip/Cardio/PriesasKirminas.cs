using Godot;
using System;

public partial class PriesasKirminas : RigidBody2D
{
	 private float speed = 100.0f; // Adjust the speed as needed
	private Vector2 velocity = new Vector2(1, 0); // Initial movement direction (to the right)

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		// Move the node
		var collision = MoveAndCollide(velocity * speed * (float)delta);

		// Check if there is a collision or the nodeg has reached the limit
		if (collision != null || (Position.X > 1000 || Position.X < 0))
		{
			// Reverse the movement direction
			velocity = -velocity;
		}
		
	}
	
	
	
}

