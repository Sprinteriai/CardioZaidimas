using Godot;
using System;

public partial class PlayerMovement : CharacterBody2D
{
	public const float Speed = 300.0f;
	public const float JumpVelocity = -550.0f;
	public const float RunningSpeed = 500.0f;

	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();
	private AnimationPlayer idleAnimation;
	private AudioStreamPlayer jumpSound;
	private int dir = 0;
	public override void _Ready()
	{
		idleAnimation = GetNode<AnimationPlayer>("IdleAnimation");
		jumpSound = GetNode<AudioStreamPlayer>("Jump");
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;

		//gravitacija
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;

		//sokinejimas
		if (Input.IsActionJustPressed("ui_up") && IsOnFloor())
			{
				velocity.Y = JumpVelocity;
				//jumpSound.Play();
				//GD.Print("Playing jump sound");
			}
			
		
		//judejimas 
		Vector2 direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		if (direction != Vector2.Zero)
		{
			idleAnimation.Stop();
			//begimas
			if (Input.IsActionPressed("ui_shift"))
			{
				velocity.X = direction.X * RunningSpeed;
			}
			//vaiksciojimas
			else
			{
				velocity.X = direction.X * Speed;
			}
			
			//judejimo animacijos
			if (velocity.X > 0)
			{
				idleAnimation.Play("TurnRight");
				dir = 1;
				
			}
			else if (velocity.X < 0)
			{
				idleAnimation.Play("TurnLeft");
				dir = 0;
				
			}
		}
		//idle animacijos
		else
		{
			velocity.X = Mathf.MoveToward(velocity.X, 0, Speed);
			if (dir ==1)
			{
				idleAnimation.Play("Idle");
			}
			else
			{
				idleAnimation.Play("IdleLeft");
			}
		}

		Velocity = velocity;
		MoveAndSlide();
	}

	
}






