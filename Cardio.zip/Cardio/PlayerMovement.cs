using Godot;
using System;

public partial class PlayerMovement : CharacterBody2D
{
	public const float Speed = 300.0f;
	public const float JumpVelocity = -700.0f;

	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();
	private AnimationPlayer idleAnimation;
	private int dir = 0;
	public override void _Ready()
	{
		idleAnimation = GetNode<AnimationPlayer>("IdleAnimation");
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;

		//gravitacija
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;

		// sokinejimas
		if (Input.IsActionJustPressed("ui_up") && IsOnFloor())
			velocity.Y = JumpVelocity;
		
		//judejimas 
		Vector2 direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		if (direction != Vector2.Zero)
		{
			velocity.X = direction.X * Speed;
			// Play walk animation
			idleAnimation.Stop(); // Stop any idle animation
			if (velocity.X > 0)
			{
				idleAnimation.Play("TurnRight");
				dir = 1;
				GD.Print(dir);
			}
			else if (velocity.X < 0)
			{
				idleAnimation.Play("TurnLeft");
				dir = 0;
				GD.Print(dir);
			}
		}
		else
		{
			velocity.X = Mathf.MoveToward(velocity.X, 0, Speed);
			 //Determine facing direction and play idle animation accordingly
			if (dir ==1)
			{
				idleAnimation.Play("Idle");
			}
			else
			{
				idleAnimation.Play("IdleLeft");
			}
		}

		Velocity = velocity;
		MoveAndSlide();
	}

	
}
