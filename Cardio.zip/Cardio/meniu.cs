using Godot;
using System;

public partial class meniu : Control
{
	
	
	private void _on_button_pressed()
{
	GetTree().ChangeSceneToFile("res://node_2d.tscn");
}
	private void _on_button_2_pressed()
{
	GetTree().Quit();
}
}






