using Godot;
using System;

public partial class PlayButton : Button
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		// Connect the pressed signal to the OnButtonPressed method
		//Connect("pressed", this, nameof(OnButtonPressed));
	}

	// Method to handle button press and scene change
	private void OnButtonPressed()
	{
		// Load the target scene
		PackedScene targetScene = GD.Load<PackedScene>("res://node_2.tscn");

		// Change to the target scene
		GetTree().ChangeScene(targetScene);
	}
}
