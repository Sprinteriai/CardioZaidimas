using Godot;
using System;

public partial class Bosas : RigidBody2D
{
	private float startingSpeed = 100f; // Adjust this value to set the initial speed of the enemy
	private float increasedSpeed = 270f; // Adjust this value to set the increased speed of the enemy
	private float currentSpeed;
	private float speedIncreaseTimer = 0f;
	private float speedIncreaseDuration = 2f; // Duration after which speed increases
	private float limitDuration = 6f;
	private bool isSpeedIncreased = false;
	private Vector2 velocity = new Vector2(1, 0); // Initial movement direction (to the right)
	Random random = new Random();
	int minSk = 1;
	int maxSk = 4;
	
	private AnimationPlayer animationPlayer;
	
	public override void _Ready()
	{
		// Initialize current speed to starting speed
		currentSpeed = startingSpeed;
		
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{	
		//int randomInRange = random.Next(minSk, maxSk);
		var progressBar = GetNode<ProgressBar>("ProgressBar");
		// Move the node
		var collision = MoveAndCollide(velocity * currentSpeed * (float)delta);
		//GD.Print(randomInRange);
		Sprite2D sprite = GetNode<Sprite2D>("Sprite2D");
		animationPlayer = sprite.GetNode<AnimationPlayer>("AnimationPlayer");
		speedIncreaseTimer += (float)delta;
		
		if(progressBar.Value == 0){
			//animationPlayer.Stop();
			currentSpeed = 0f;
			GetTree().ChangeSceneToFile("res://game_end.tscn");
			
			
			//GetTree().ChangeSceneToFile("res://game_end.tscn");
		} else {
			if(progressBar.Value <= 75){
				increasedSpeed = 400f;
				speedIncreaseDuration = 1f;
			}
			else{
				increasedSpeed = 200f;
				speedIncreaseDuration = 2f;
			}
			if(currentSpeed == increasedSpeed){
				if(velocity.X > 0){
					animationPlayer.Play("dash_right");
				}
				else if(velocity.X < 0){
					animationPlayer.Play("dash_left");
				}
			}
			
			if (speedIncreaseTimer >= speedIncreaseDuration)
			{
			// Increase speed
				int randomInRange = random.Next(minSk, maxSk);
			//GD.Print(randomInRange);
				if(randomInRange == 1){
					currentSpeed = increasedSpeed;
				}
				else if(randomInRange == 2){
					currentSpeed = startingSpeed;
				}
				else if(randomInRange == 3){
					//animationPlayer.Stop();
					currentSpeed = 0f;
					if(velocity.X > 0){
						animationPlayer.Play("attack1_right");
						animationPlayer.Queue("idle_right");
					}
					else if(velocity.X < 0){
						animationPlayer.Play("attack1_left");
						animationPlayer.Queue("idle_left");
					
					}
					progressBar.Value += 10;
				}
			
				speedIncreaseTimer = 0f;
			}
			
			if (collision != null)
			{
				velocity = -velocity;
				if(velocity.X > 0){
					animationPlayer.Play("walk_boss_right");
				}
				else if(velocity.X < 0){
					animationPlayer.Play("walk_boss_left");
				}
			
			}
			
		}
		
		
	}
	public void TakeDamage()
	{
		// Play the "taking damage" animation

		var progressBar = GetNode<ProgressBar>("ProgressBar");
		//animationPlayer.Play("take_dmg");
		progressBar.Value -= 10;
	}
	private void _on_area_2d_body_entered(Node2D body)
	{
		Sprite2D sprite = GetNode<Sprite2D>("Sprite2D");
		animationPlayer = sprite.GetNode<AnimationPlayer>("AnimationPlayer");
		
		var progressBar = GetNode<ProgressBar>("ProgressBar");
		// Replace with function body.
		if(body.Name == "Bullet"){
			//GYVYBES
			//animationPlayer.Stop();
			TakeDamage();
		}
		
	}
}
