using Godot;
using System;

public partial class PriesasKirminas : RigidBody2D
{
	 private float speed = 100.0f; // Adjust the speed as needed
	private Vector2 velocity = new Vector2(1, 0); // Initial movement direction (to the right)

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		// Move the node
		var collision = MoveAndCollide(velocity * speed * (float)delta);

		// Check if there is a collision or the nodeg has reached the limit
		if (collision != null)
		{
			// Reverse the movement direction
			velocity = -velocity;
		}
		
	}
	private void _on_area_2d_body_entered(Node2D body)
	{
		// Replace with function body.
		if(body.Name == "CharacterBody2D"){
			//GYVYBES
			var progressBar = GetNode<ProgressBar>("../CharacterBody2D/ProgressBar");
			progressBar.Value -= 10;
		}
	}
	
	
	
}




