using Godot;
using System;

public partial class PowerUp : Area2D
{
private void _on_body_entered(Node2D body)
{
		GetTree().ChangeSceneToFile("res://PowerUp.tscn");
}

}


