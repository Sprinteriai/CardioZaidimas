using Godot;
using System;

public partial class Kliutys : Area2D
{
	public override void _Ready()
	{
		// Note: Assuming you are using Godot 4.0 or later.
		var callable = new Callable(this, nameof(OnBodyEntered));
		Connect("body_entered", callable);
	}

	private void OnBodyEntered(Node body)
	{
		if (body.Name == "CharacterBody2D") // C# type check and cast
		{
			var progressBar = GetNode<ProgressBar>("../CharacterBody2D/ProgressBar");
			if (progressBar != null)
			{
			progressBar.Value -= 10;
			}
		}
		}
	}
