using Godot;
using System;

public partial class PowerUpButtons : Control
{
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{	
		
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		
	}
	
	private void _on_button_pressed()
{
	
	PlayerMovement.JumpVelocity = -450.0f;
	GetTree().ChangeSceneToFile("res://Level1.tscn");
}
private void _on_button_2_pressed()
{
	PlayerMovement.Speed = 400.0f;
	PlayerMovement.RunningSpeed = 500.0f;
	GetTree().ChangeSceneToFile("res://Level1.tscn");
}
private void _on_button_3_pressed()
{
	//Kazkas tokio maybe?
	//PlayerMovement.HP.value = 100;
	GetTree().ChangeSceneToFile("res://Level1.tscn");
}


	
}








