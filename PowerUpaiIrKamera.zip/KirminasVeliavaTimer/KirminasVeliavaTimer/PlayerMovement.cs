using Godot;
using System;

public partial class PlayerMovement : CharacterBody2D
{
	public static float Speed = 300.0f;
	public static float JumpVelocity = -550.0f;
	public static float RunningSpeed = 500.0f;
	
	public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle();
	private AnimatedSprite2D idleAnimation;
	private AudioStreamPlayer jumpSound;
	private ProgressBar HP;
	private int dir = 0;
	bool messagePrinted = false;
	public override void _Ready()
	{
		HP = GetNode<ProgressBar>("ProgressBar");
		idleAnimation = GetNode<AnimatedSprite2D>("Sprite2D");
		jumpSound = GetNode<AudioStreamPlayer>("Jump");
	}

	public override void _PhysicsProcess(double delta)
	{
		Vector2 velocity = Velocity;
		if(HP.Value == 0 && !messagePrinted){
			GD.Print("");
			GetTree().ChangeSceneToFile("res://game_end_lose.tscn");
			messagePrinted = true;
		}
		//gravitacija
		if (!IsOnFloor())
			velocity.Y += gravity * (float)delta;

		//sokinejimas
		if (Input.IsActionJustPressed("ui_up") && IsOnFloor())
			{
				velocity.Y = JumpVelocity;
				//jumpSound.Play();
				//GD.Print("Playing jump sound");
			}
			
		
		//judejimas 
		Vector2 direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		
		
		if (direction != Vector2.Zero)
		{
			
			//begimas
			if (Input.IsActionPressed("ui_shift"))
			{
				velocity.X = direction.X * RunningSpeed;
			}
			//vaiksciojimas
			else
			{
				velocity.X = direction.X * Speed;
			}
			
			
			if (Input.IsActionPressed("ui_right"))
			{
				idleAnimation.Play("MoveRight");
				dir = 1;
				
			}
			else if (Input.IsActionPressed("ui_left"))
			{
				idleAnimation.Play("MoveLeft");
				dir = 0;
				
			}
			
			//judejimo animacijos
			
			
		}
		//idle animacijos
		
	else
		{
			velocity.X = Mathf.MoveToward(velocity.X, 0, Speed);
			if (velocity.X == 0) // Fully stopped
			{
				if (dir == 1)
				{
					idleAnimation.Play("IdleRight");
				}
				else
				{
					idleAnimation.Play("IdleLeft");
				}
			}
		}
		
		Velocity = velocity;
		MoveAndSlide();
	}

	
}



