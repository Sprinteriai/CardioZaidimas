using Godot;
using System;
//using System.Collections.Generic;

public partial class game_end : Control
{
	
public Godot.Collections.Dictionary<string, double> Save()
{
	double timeLeft = (double)laikmat.TimerTimeLeft;
	return new Godot.Collections.Dictionary<string, double>()
	{
		{ "TimeLeft",  timeLeft}
	};
	}
	/*public void SaveGame()
	{
		var saveGame = new File();
		saveGame.Open("res://scoreboard.txt", (int)File.ModeFlags.Write);
		var saveNodes = GetTree().GetNodesInGroup("Persist");
		foreach (Node saveNode in saveNodes)
		{
			
		}
	}
	*/

	public override void _Ready()
	{
		
		GridContainer gridContainer = GetNode<GridContainer>("GridContainer");
		float timeLeft = laikmat.TimerTimeLeft;
		GD.Print(timeLeft);
		Label label = gridContainer.GetNode<Label>("Laikas");
		label.Text ="You completed the game with "+ timeLeft.ToString("F2")+" seconds left";
		
	}
	
		
	
	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		
		
	}
	private void _on_button_play_again_pressed()
{
	GetTree().ChangeSceneToFile("res://node_2d.tscn");
}

private void _on_button_quit_pressed()
{
	GetTree().Quit();
}

}




