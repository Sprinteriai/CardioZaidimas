using Godot;
using System;

public partial class Gun : Node2D
{
	[Export] PackedScene bullet_scn;
	[Export] float bullet_speed = 500f;
	[Export] float bullet_speed2 = -500f;
	[Export] float bps = 5f;
	[Export] float bullet_damage = 30f;
	
	float fire_rate;
	float time_until_fire = 0f;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		fire_rate = 1 / bps;
	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if (Input.IsActionPressed("ui_left"))
			{
				bullet_speed = -500f;
			}
			else if (Input.IsActionPressed("ui_right"))
			{
				bullet_speed = 500f;
			}
		if (Input.IsActionJustPressed("ui_select") && time_until_fire > fire_rate)
		{
			RigidBody2D bullet = bullet_scn.Instantiate<RigidBody2D>();
			bullet.Rotation = GlobalRotation;
			bullet.GlobalPosition = GlobalPosition;
			
			bullet.LinearVelocity = bullet.Transform.X * bullet_speed;
			GetTree().Root.AddChild(bullet);
			time_until_fire = 0f;
		}
		/*else if (Input.IsActionJustPressed("ui_select") && time_until_fire > fire_rate && Input.IsActionPressed("ui_left"))
		{
			RigidBody2D bullet = bullet_scn.Instantiate<RigidBody2D>();
			bullet.Rotation = GlobalRotation;
			bullet.GlobalPosition = GlobalPosition;
			bullet.LinearVelocity = bullet.Transform.X * bullet_speed2;
			GetTree().Root.AddChild(bullet);
			time_until_fire = 0f;
		}*/
		else
		{
			time_until_fire += (float)delta;
		}
	}
}
