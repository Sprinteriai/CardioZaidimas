using Godot;
using System;

public partial class game_end : Control
{
	private void _on_button_play_again_pressed()
{
	GetTree().ChangeSceneToFile("res://node_2d.tscn");
}

private void _on_button_quit_pressed()
{
	GetTree().Quit();
}
}



